<!DOCTYPE html>
<html>
    <head>
	    <meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<style>
		</style>
		<link href="../css/styles.css" rel="stylesheet" type="text/css" />
        <title>Библиотека</title>
    </head>
    <body>
			<form method="post" class="form" action="index.php?action=add<?php if (isset($_GET['admin'])) echo '&admin';?>">
                <h1>Библиотека</h1>
                <h2>Новая книга</h2>
                <input class="inputField--description focused" name="title" type="search" placeholder="Название книги" required autofocus>
				<input class="inputField--author focused" name="author" type="search" placeholder="Автор">
                <textarea class="inputField--content focused" name="description" placeholder="Фрагмент (по желанию)"></textarea>
                <input class="inputField--author focused" name="contributor" type="search" placeholder="Ваше имя (по желанию)">
                <input name="date" type="hidden" value="<?=date('d-m-Y H:i:s')?>">
                <input name="contributor_IP" type="hidden" value="<?=$_SERVER['REMOTE_ADDR']?>">
				<button class="button" type="submit"><span class="default__symbols--contactSend"></span>Сохранить</button>
                <a href="<?php if (!isset($_GET['admin'])) echo '../';?>index.php"><div class="button"><span class="default__symbols--contactSend"></span><?php if (!isset($_GET['admin'])) echo 'Каталог'; else echo 'Редактор библиотеки';?></div></a>
			</form>
                <!--button class="button--shy"><span class="default__symbols--contactSend"></span>Отмена</button-->

    </body>
</html>