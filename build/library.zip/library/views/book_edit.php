<!DOCTYPE html>
<html>
    <head>
	    <meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<style>
		</style>
		<link href="../css/styles.css" rel="stylesheet" type="text/css" />
        <title>Библиотека</title
    </head>
    <body>
			<form method="post" class="form" action="index.php?action=edit&id=<?=$books['id']?>">
                <h2>Редактировать книгу</h2>
                <input class="inputField--description focused" name="title" type="text" placeholder="Название книги" value="<?=$books['title']?>" required>
				<input class="inputField--author focused" name="author" type="text" placeholder="Автор" value="<?=$books['author']?>"><br>
                <textarea class="inputField--content focused" name="description" placeholder="Фрагмент (по желанию)"><?=$books['description']?></textarea>
                <small>Исправление: <?=$books['change_date']?></small><br>
                <small>Добавление: <?=$books['date']?></small>
                <input name="change_date" type="hidden" value="<?=date('d-m-Y H:i:s')?>">
                <input name="editor_IP" type="hidden" value="<?=$_SERVER['REMOTE_ADDR']?>">
				<button class="button" type="submit"><span class="default__symbols--contactSend"></span>Сохранить</button>
                <a href="<?php if(isset($_GET['admin'])) echo 'index.php'; 
                                else echo '../index.php';?>" class="button"><!--span class="default__symbols--contactSend"></span-->Отмена</a>            
			</form>

    </body>
</html>