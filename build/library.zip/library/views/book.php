<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> <style></style>
        <link href="css/styles.css" rel="stylesheet" type="text/css" />
        <title>БИБЛИОТЕКА.книга</title>
    </head>
    <body>
        <div class="form">
        <h1 <?php if(isset($_GET['admin'])) echo 'class="warning"';?>>Библиотека</h1>
        <h2>"<?=$book['title']?>"</h2>
        <h3><?=$book['author']?></h3>
        <?php               if(isset($_GET['admin'])) 
                                echo '<small>Исправлена: '.$book['change_date'].'</small><br>
                                      <small>Добавлена: '.$book['date'].'</small>';
                            else
                                echo '<small>Добавлена: '.intro($book['date'],16).'</small>';?><br>
        
        <?php if(empty($book['description'])) echo '<i>Нет описания. Вы можете добавить его, нажав кнопку "Редактировать"</i>'; 
            else echo '<p class="book_read">'.$book['description'].'</p>';?>
         
            
        <a href="admin/index.php?action=edit&id=<?=$book['id'];?><?php if(isset($_GET['admin'])) echo '&admin'?>"><button class="button" type="submit"><span class="default__symbols--contactSend"></span>Редактировать</button></a>
		<!--a href="index.php?action=add"><button class="button" type="submit"><span class="default__symbols--contactSend"></span>Добавить книгу</button></a-->
        <a href="index.php"><button class="button"><span class="default__symbols--contactSend"></span>Каталог</button></a>
        </div>
    </body>
</html>